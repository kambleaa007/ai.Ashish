import pino from 'pino';
import { env } from './config/env.js';

export const logger = pino({
  level: env.NODE_ENV === 'production' ? 'info' : 'debug',
  redact: {
    paths: [
      'req.headers.authorization',
      'req.headers.cookie',
      'headers.authorization',
      'headers.cookie',
      'password',
      '*.password',
      'passwordHash',
      '*.passwordHash',
      'refreshToken',
      '*.refreshToken',
      'accessToken',
      '*.accessToken',
      'token',
      'tokenHash',
    ],
    censor: '[REDACTED]',
  },
});
